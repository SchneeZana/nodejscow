const information = require('./information');
const cowsay = require('cowsay');

console.log(cowsay.say({
  text: `My name is ${information.name} and I am from ${information.campus}.`
}));
