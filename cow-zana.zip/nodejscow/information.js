const information = {
  name: 'Snjezana',
  campus: 'Darmstadt'
};

module.exports = information;